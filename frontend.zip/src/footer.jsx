function footer() {
    return(
        <div>Made with ❤️ by <strong>Powerpuff Girls</strong> </div>
    );
}